#include<stdio.h>
#include<string.h>
int main()
{
	char c[]={"happy birthday"};
char str[3][10];
char string[10];
int i;
for(i=0;i<3;i++)
gets(str[i]);
if(strcmp(str[0],str[1])>0)
strcpy(string,str[0]);
else
 strcpy(string,str[1]);
if(strcmp(str[2],string)>0)
strcpy(string,str[2]);
printf("%s\n",string[10]);
return 0;

}