#include<stdio.h>
int main()
{int i,j=1,sum=0;
for(i=1;i<=5;i++)
{
j=j*i;
sum=sum+j;
}
printf("%d",j);}