#include<stdio.h>
#include<math.h>
int main()
{
	int i=0;
	int count=0;
		int j=0;
	for(i=100;i<=250;i++)
	{
		for(j=2;j<sqrt(i);j++)
		{	
			if(i%j==0)
			{
				break;
			}
		}
	
	if(j>sqrt(i))
	{
		printf("%d ",i);
		count++;
	}
	}


printf("\n%d\n",count);




	return 0;

}