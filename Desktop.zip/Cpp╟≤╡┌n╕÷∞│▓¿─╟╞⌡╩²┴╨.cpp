#include<stdio.h>
int fac(int n)
{
	int a=1,b=1,c=1;
	
	while(n>2)
	{
		c=a+b;
		a=b;
		b=c;
		n--;
//		sum+=c;
	}
	return c;
	






}
int main()
{
	int n,ret;
	scanf("%d",&n);
	ret=fac(n);
	printf("%d\n",ret);





return 0;
}