#include<stdio.h>
int* test()
{
	int a=10;
	return &a;


}
int main()
{
//	int a=10;
	int*p=test();
	printf("%d ",*p);





}